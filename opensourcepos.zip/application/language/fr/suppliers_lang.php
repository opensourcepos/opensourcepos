<?php 

$lang["suppliers_account_number"] = "# Compte";
$lang["suppliers_basic_information"] = "Informations fournisseur";
$lang["suppliers_cannot_be_deleted"] = "Impossible de supprimer le(s) fournisseur(s) sélectionné(s). Un ou plusieurs ont des ventes.";
$lang["suppliers_company_name"] = "Nom d\'Entreprise";
$lang["suppliers_company_name_required"] = "Le Nom d\'Entreprise est un champ requis";
$lang["suppliers_agency_name"] = "Nom d\'Agence";
$lang["suppliers_confirm_delete"] = "Etes vous sûr(e) de vouloir supprimer ce(s) fournisseur(s)?";
$lang["suppliers_error_adding_updating"] = "Error lors de l\'ajout/suppression de fournisseur";
$lang["suppliers_new"] = "Nouveau Fournisseur";
$lang["suppliers_none_selected"] = "Vous n\\\'avez pas sélectionné de fournisseur à supprimer";
$lang["suppliers_one_or_multiple"] = "fournisseur(s)";
$lang["suppliers_successful_adding"] = "Fournisseur ajouté avec succès";
$lang["suppliers_successful_deleted"] = "Suppression réussie";
$lang["suppliers_successful_updating"] = "Fournisseur édité avec succès";
$lang["suppliers_supplier"] = "Fournisseur";
$lang["suppliers_supplier_id"] = "Id";
$lang["suppliers_update"] = "Éditer Fournisseur";
