<?php 

$lang["login_go"] = "ходите";
$lang["login_invalid_username_and_password"] = "Неправелная Имя/Пароль";
$lang["login_login"] = "Вход";
$lang["login_password"] = "Пароль";
$lang["login_username"] = "Имя";
$lang["login_welcome_message"] = "Добро пожаловать в Open Source Point of Sale. Чтобы продолжить, пожалуйста войдите на сайт, используя имя и пароль.";
