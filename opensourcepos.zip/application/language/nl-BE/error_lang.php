<?php 

$lang["error_no_permission_module"] = "U hebt geen toegang tot de module genaamd ";
$lang["error_unknown"] = "onbekend";
