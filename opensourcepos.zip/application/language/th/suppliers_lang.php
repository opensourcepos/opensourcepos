<?php 

$lang["suppliers_account_number"] = "บัญชี #";
$lang["suppliers_basic_information"] = "ข้อมูลผู้ผลิต";
$lang["suppliers_cannot_be_deleted"] = "ลบผู้ผลิตที่ถูกเลือกไม่ได้, one or more of the selected suppliers has sales.";
$lang["suppliers_company_name"] = "ชื่อบริษัท";
$lang["suppliers_company_name_required"] = "ชื่อบริษัทต้องกรอก";
$lang["suppliers_agency_name"] = " ";
$lang["suppliers_confirm_delete"] = "แน่ใจหรือไม่ที่จะลบผู้ผลิตที่ถููกเลือก?";
$lang["suppliers_error_adding_updating"] = "เพิ่ม/แก้ไข ผู้ผลิต ล้มเหลว";
$lang["suppliers_new"] = "ผู้ผลิตรายใหม่";
$lang["suppliers_none_selected"] = "คุณยังไม่ได้เฃือกผู้ผลิตที่ต้องการลบ";
$lang["suppliers_one_or_multiple"] = "ผู้ผลิต";
$lang["suppliers_successful_adding"] = "เพิ่มผู้ผลิตสำเร็จ";
$lang["suppliers_successful_deleted"] = "ลบสำเร็จ";
$lang["suppliers_successful_updating"] = "ปรับปรุงผู้ผลิตสำเร็จ";
$lang["suppliers_supplier"] = "ผู้ผลิต";
$lang["suppliers_supplier_id"] = "Id";
$lang["suppliers_update"] = "ปรับปรุงผู้ผลิต";
