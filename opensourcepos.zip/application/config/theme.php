<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

/*
|--------------------------------------------------------------------------
| theme name
|--------------------------------------------------------------------------
|
| the theme folder name. If the folder doesn't exist it will use default theme
|
|
*/
$config['theme_name'] = 'flatly';
//$config['theme_name'] = 'spacelab';
